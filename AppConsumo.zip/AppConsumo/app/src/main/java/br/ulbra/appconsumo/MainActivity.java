package br.ulbra.appconsumo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText vehicleName, plateNumber, distance, fuelConsumption, fuelPrice;
    TextView resultText;
    Button calculateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vehicleName = findViewById(R.id.vehicleName);
        plateNumber = findViewById(R.id.plateNumber);
        distance = findViewById(R.id.distance);
        fuelConsumption = findViewById(R.id.fuelConsumption);
        fuelPrice = findViewById(R.id.fuelPrice);
        resultText = findViewById(R.id.resultText);
        calculateButton = findViewById(R.id.calculateButton);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String distanceStr = distance.getText().toString();
                String fuelConsumptionStr = fuelConsumption.getText().toString();
                String fuelPriceStr = fuelPrice.getText().toString();

                if (!distanceStr.isEmpty() && !fuelConsumptionStr.isEmpty() &&
                        !fuelPriceStr.isEmpty()) {

                    double distanceValue = Double.parseDouble(distanceStr);
                    double fuelConsumptionValue = Double.parseDouble(fuelConsumptionStr);
                    double fuelPriceValue = Double.parseDouble(fuelPriceStr);

                    double fuelNeeded = distanceValue / fuelConsumptionValue;

                    double tripCost = fuelNeeded * fuelPriceValue;

                    resultText.setText("Combustível necessário: " + fuelNeeded + " Custo da viagem: R$" + tripCost);
                } else {

                    resultText.setText("Por favor, preencha todos os campos.");
                }
            }

        });
    }
}
